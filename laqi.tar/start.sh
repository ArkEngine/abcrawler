#!/bin/sh
cd $(dirname $0)
nohup ./sv_flexse . &
