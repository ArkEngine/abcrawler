#!/bin/sh
cd $(dirname $0)
killall sv_flexse
killall flexse
